const mysql = require('mysql2');
const db = require('../config/db');  // Assuming you have a separate config file for DB connection

const registerVendor = (data, callback) => {
    const query = `
        INSERT INTO Vendor (VendorName, ContactInfo, EmailAddress, ComplianceCertifications, PerformanceRating)
        VALUES (?, ?, ?, ?, ?);
    `;
    
    db.query(query, data, (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return callback(err);
        }
        callback(null, results);
    });
};

module.exports = { registerVendor };
