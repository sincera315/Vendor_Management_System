const mysql = require('mysql2');

// Database Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'kaddict.345',
    database: 'Vendor_Contract_Management_System'
});

// Connect to the database
db.connect((err) => {
    if (err) {
        console.error("Database connection failed:", err.stack);
        return;
    }
    console.log("Database connected successfully.");
});

// Export the database connection for use in other modules
module.exports = db;
