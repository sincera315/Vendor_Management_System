// Vendor Form Submission
// Vendor Form Submission
document.getElementById('vendorForm').addEventListener('submit', (e) => {
    e.preventDefault();  // Prevent form from submitting the default way

    // Log to make sure the function is called
    console.log('Form submitted, starting to collect data...');

    const formData = new FormData(e.target);  // Get form data
    const vendorData = Object.fromEntries(formData.entries());  // Convert form data to JSON format

    console.log("Form Data:", vendorData);  // Log form data

    // Check if the vendor data contains all necessary fields before sending the request
    if (!vendorData.VendorName || !vendorData.ContactInfo || !vendorData.EmailAddress || !vendorData.PerformanceRating) {
        console.error('Missing required fields');
        alert('Please fill in all required fields!');
        return;
    }

    // Make the POST request to the backend API
    console.log('Sending data to the server...');
    fetch('/register-vendor', {  // Match the server-side route here
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(vendorData),  // Send the form data as JSON
    })
    .then(response => {
        console.log('Server responded with status:', response.status);
        
        // Check if the response is ok (status code 200-299)
        if (!response.ok) {
            console.error('Failed to register vendor. Status:', response.status);
            return Promise.reject('Failed to register vendor');
        }
        
        return response.json();  // Parse the response as JSON
    })
    .then(data => {
        console.log("Response from server:", data);  // Log the response from the server
        alert(data.message);  // Show success message
    })
    .catch(error => {
        console.error('Error occurred during form submission:', error);
        alert('An error occurred while submitting the form. Please try again later.');
    });
});



// Contract Form Submission
document.getElementById('contractForm')?.addEventListener('submit', function (e) {
    e.preventDefault();
    const contractData = {
        ContractName: this.ContractName.value,
        StartDate: this.StartDate.value,
        EndDate: this.EndDate.value,
        VendorId: this.VendorId.value,
    };

    fetch('/api/contracts/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(contractData),
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        this.reset();
    })
    .catch(error => console.error('Error:', error));
});

// Purchase Order Form Submission
document.getElementById('purchaseOrderForm')?.addEventListener('submit', function (e) {
    e.preventDefault();
    const orderData = {
        OrderNumber: this.OrderNumber.value,
        VendorId: this.VendorId.value,
        OrderDetails: this.OrderDetails.value,
    };

    fetch('/api/purchase-orders/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData),
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        this.reset();
    })
    .catch(error => console.error('Error:', error));
});

// Performance Evaluation Form Submission
document.getElementById('performanceForm')?.addEventListener('submit', function (e) {
    e.preventDefault();
    const performanceData = {
        VendorId: this.VendorId.value,
        PerformanceRating: this.PerformanceRating.value,
        Comments: this.Comments.value,
    };

    fetch('/api/performance/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(performanceData),
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        this.reset();
    })
    .catch(error => console.error('Error:', error));
});