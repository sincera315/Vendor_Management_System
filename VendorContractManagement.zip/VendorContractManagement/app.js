const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const vendorRoutes = require('./routes/vendorRoutes');
const contractRoutes = require('./routes/contractRoutes');
const purchaseOrderRoutes = require('./routes/purchaseOrderRoutes');
const performanceRoutes = require('./routes/performanceRoutes');
const portalRoutes = require('./routes/portalRoutes');
const employeeRoutes = require('./routes/employeeRoutes');

// Import the database connection
const db = require('./config/db');

const app = express();
const port = 8080;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, 'public')));
app.use('/portal', portalRoutes);

// Serve the main page (index.html) at the root URL
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// Serve portal pages
app.get('/vendor-portal', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'vendorPortal.html'));
});

app.get('/procurement-portal', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'procurementPortal.html'));
});

// Serve form pages directly
app.get(['/vendorForm', '/vendorForm.html'], (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'vendorForm.html'));
});

app.get('/contractForm.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'contractForm.html'));
});

app.get('/purchaseOrderForm.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'purchaseOrderForm.html'));
});

app.get('/performanceForm.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'performanceForm.html'));
});

// Use employee routes for employee-related functionality
app.use('/api/employees', employeeRoutes);

// API routes
app.use('/api/vendors', vendorRoutes);
app.use('/api/contracts', contractRoutes);
app.use('/api/purchase-orders', purchaseOrderRoutes);
app.use('/api/performance', performanceRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something went wrong!');
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
