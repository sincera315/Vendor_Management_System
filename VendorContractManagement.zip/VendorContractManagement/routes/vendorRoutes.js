const express = require('express');
const router = express.Router();
const Vendor = require('../models/vendorModel');  // Assuming this file contains the registerVendor method

// Route to handle vendor registration
router.post('/register', (req, res) => {
    const { VendorName, ContactInfo, EmailAddress, ComplianceCertifications, PerformanceRating } = req.body;

    // Log received data for debugging
    console.log('Received data:', { VendorName, ContactInfo, EmailAddress, ComplianceCertifications, PerformanceRating });

    // Sanitize input (optional, but recommended)
    const vendorData = [
        VendorName,
        ContactInfo,
        EmailAddress,
        ComplianceCertifications,
        PerformanceRating
    ];

    // Log the data being passed to the model
    console.log('Passing data to registerVendor method:', vendorData);

    Vendor.registerVendor(vendorData, (err, results) => {
        if (err) {
            console.error('Database error:', err.message);
            return res.status(500).json({ message: 'Failed to add data to the database.' });
        }

        // Log the results from the stored procedure
        console.log('Database operation result:', results);

        res.status(200).json({ message: 'Data has been added to the database successfully!' });
    });
});

module.exports = router;
