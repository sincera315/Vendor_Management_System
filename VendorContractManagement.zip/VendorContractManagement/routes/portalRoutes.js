const express = require('express');
const router = express.Router();
const path = require('path');

// Vendor Portal
router.get('/vendor', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/vendorPortal.html'));
});

// Procurement Portal
router.get('/procurement', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/procurementPortal.html'));
});
module.exports = router;
